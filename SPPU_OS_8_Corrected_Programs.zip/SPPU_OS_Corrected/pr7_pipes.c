#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#define SIZE 1024
int main(void){
    int p1[2],p2[2];
    if(pipe(p1)<0||pipe(p2)<0){perror("pipe");return 1;}
    pid_t pid=fork();if(pid<0){perror("fork");return 1;}
    if(pid==0){
        close(p1[1]);close(p2[0]);
        char name[SIZE];size_t pos=0;char c;ssize_t n;
        while(pos<SIZE-1&&(n=read(p1[0],&c,1))==1&&c!='\0')name[pos++]=c;
        name[pos]='\0';close(p1[0]);
        FILE *fp=fopen(name,"rb");
        if(!fp){const char *msg="Error: cannot open file\n";write(p2[1],msg,strlen(msg));}
        else{char buf[SIZE];size_t count;
            while((count=fread(buf,1,sizeof buf,fp))>0){size_t off=0;while(off<count){ssize_t w=write(p2[1],buf+off,count-off);if(w<=0){perror("write");fclose(fp);close(p2[1]);_exit(1);}off+=(size_t)w;}}
            fclose(fp);
        }
        close(p2[1]);_exit(0);
    }
    close(p1[0]);close(p2[1]);
    char name[SIZE];printf("Enter file name: ");fflush(stdout);
    if(!fgets(name,sizeof name,stdin)){close(p1[1]);close(p2[0]);waitpid(pid,NULL,0);return 1;}
    name[strcspn(name,"\n")]='\0';
    size_t len=strlen(name)+1,off=0;
    while(off<len){ssize_t w=write(p1[1],name+off,len-off);if(w<=0){perror("write");break;}off+=(size_t)w;}
    close(p1[1]);
    printf("File contents:\n");fflush(stdout);
    char buf[SIZE];ssize_t n;
    while((n=read(p2[0],buf,sizeof buf))>0)fwrite(buf,1,(size_t)n,stdout);
    if(n<0)perror("read");
    close(p2[0]);waitpid(pid,NULL,0);
    return n<0?1:0;
}
