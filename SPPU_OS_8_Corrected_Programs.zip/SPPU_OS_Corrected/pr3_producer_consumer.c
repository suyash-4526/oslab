#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#define SIZE 5
int buffer[SIZE], in=0, out=0;
sem_t empty, full;
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
void *producer(void *arg){
    (void)arg;
    for(int i=1;i<=5;i++){
        sem_wait(&empty);pthread_mutex_lock(&mutex);
        buffer[in]=i;printf("Produced: %d\n",i);in=(in+1)%SIZE;
        pthread_mutex_unlock(&mutex);sem_post(&full);sleep(1);
    }return NULL;
}
void *consumer(void *arg){
    (void)arg;
    for(int i=1;i<=5;i++){
        sem_wait(&full);pthread_mutex_lock(&mutex);
        int item=buffer[out];out=(out+1)%SIZE;
        printf("Consumed: %d\n",item);
        pthread_mutex_unlock(&mutex);sem_post(&empty);sleep(1);
    }return NULL;
}
int main(void){
    pthread_t p,c;
    if(sem_init(&empty,0,SIZE)!=0||sem_init(&full,0,0)!=0){perror("sem_init");return 1;}
    if(pthread_create(&p,NULL,producer,NULL)!=0){puts("Thread creation failed");return 1;}
    if(pthread_create(&c,NULL,consumer,NULL)!=0){puts("Thread creation failed");return 1;}
    pthread_join(p,NULL);pthread_join(c,NULL);
    sem_destroy(&empty);sem_destroy(&full);pthread_mutex_destroy(&mutex);
    return 0;
}
