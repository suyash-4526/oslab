#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>
#define SIZE 1024
int main(void){
    if(mkfifo("fifo1",0666)<0&&errno!=EEXIST){perror("mkfifo1");return 1;}
    if(mkfifo("fifo2",0666)<0&&errno!=EEXIST){perror("mkfifo2");return 1;}
    int fd=open("fifo1",O_WRONLY);if(fd<0){perror("open fifo1");return 1;}
    char buf[SIZE];
    printf("Enter sentences (Ctrl+D on a new line to finish):\n");fflush(stdout);
    while(fgets(buf,sizeof buf,stdin)){
        size_t len=0;while(buf[len])len++;
        size_t off=0;
        while(off<len){ssize_t w=write(fd,buf+off,len-off);if(w<=0){perror("write");close(fd);return 1;}off+=(size_t)w;}
    }
    close(fd);
    fd=open("fifo2",O_RDONLY);if(fd<0){perror("open fifo2");return 1;}
    puts("Result received:");ssize_t n;
    while((n=read(fd,buf,sizeof buf))>0)fwrite(buf,1,(size_t)n,stdout);
    if(n<0)perror("read");
    close(fd);
    return n<0?1:0;
}
