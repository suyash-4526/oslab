#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#define N 5
sem_t forks[N], room;
void *philosopher(void *arg){
    int id=*(int *)arg;
    for(int i=0;i<2;i++){
        printf("Philosopher %d thinking\n",id);
        sem_wait(&room);
        sem_wait(&forks[id]);
        sem_wait(&forks[(id+1)%N]);
        printf("Philosopher %d eating\n",id);sleep(1);
        sem_post(&forks[(id+1)%N]);sem_post(&forks[id]);
        sem_post(&room);
        printf("Philosopher %d finished\n",id);
    }return NULL;
}
int main(void){
    pthread_t t[N];int id[N];
    for(int i=0;i<N;i++)if(sem_init(&forks[i],0,1)!=0){perror("sem_init");return 1;}
    if(sem_init(&room,0,N-1)!=0){perror("sem_init");return 1;}
    for(int i=0;i<N;i++){
        id[i]=i;
        if(pthread_create(&t[i],NULL,philosopher,&id[i])!=0){puts("Thread creation failed");return 1;}
    }
    for(int i=0;i<N;i++)pthread_join(t[i],NULL);
    for(int i=0;i<N;i++)sem_destroy(&forks[i]);
    sem_destroy(&room);
    return 0;
}
