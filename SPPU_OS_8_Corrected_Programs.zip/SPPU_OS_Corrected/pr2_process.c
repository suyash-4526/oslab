#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

void sort(int a[], int n) {
    for (int i=0;i<n-1;i++)
        for (int j=0;j<n-i-1;j++)
            if (a[j]>a[j+1]) { int t=a[j];a[j]=a[j+1];a[j+1]=t; }
}
int main(void) {
    int a[20],n;
    printf("Number of elements (1-20): "); fflush(stdout);
    if(scanf("%d",&n)!=1 || n<1 || n>20) return 1;
    printf("Enter elements: "); fflush(stdout);
    for(int i=0;i<n;i++) if(scanf("%d",&a[i])!=1) return 1;
    fflush(stdout);
    pid_t pid=fork();
    if(pid<0){perror("fork");return 1;}
    if(pid==0){sort(a,n);printf("Child sorted: ");for(int i=0;i<n;i++)printf("%d ",a[i]);printf("\n");fflush(stdout);_exit(0);}
    sort(a,n);waitpid(pid,NULL,0);
    printf("Parent sorted: ");for(int i=0;i<n;i++)printf("%d ",a[i]);printf("\n");fflush(stdout);
    pid=fork();
    if(pid<0){perror("fork");return 1;}
    if(pid==0)_exit(0);
    printf("Zombie demo: child %ld exited; parent waits 2 seconds before reaping.\n",(long)pid);fflush(stdout);
    sleep(2);waitpid(pid,NULL,0);
    pid=fork();
    if(pid<0){perror("fork");return 1;}
    if(pid==0){sleep(2);printf("Orphan demo: child PID %ld, new PPID %ld\n",(long)getpid(),(long)getppid());fflush(stdout);_exit(0);}
    printf("Orphan demo: original parent exiting now.\n");fflush(stdout);
    return 0;
}
