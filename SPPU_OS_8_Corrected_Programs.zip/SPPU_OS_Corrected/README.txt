SPPU OS 2024 Pattern - 8 Corrected Practical Assignments
Linux/Ubuntu instructions. The source files are the deliverables; executables can be rebuilt.

1 Address Book:
  chmod +x pr1_addressbook.sh
  ./pr1_addressbook.sh
  Example: choice 1, then 3 with Asha/123/Pune, then 2 displays Asha|123|Pune.

2 Process Management:
  gcc pr2_process.c -o pr2_process
  ./pr2_process
  Input: 5 then 5 2 9 1 3
  Sample: Child sorted: 1 2 3 5 9 / Parent sorted: 1 2 3 5 9
  Zombie demo lasts 2 seconds. Orphan output may arrive after shell prompt.

3 Producer Consumer:
  gcc pr3_producer_consumer.c -o pr3_producer_consumer -pthread
  ./pr3_producer_consumer
  Output includes Produced: 1 / Consumed: 1 through item 5. Order may vary.

4 Dining Philosophers:
  gcc pr4_dining.c -o pr4_dining -pthread
  ./pr4_dining
  Output includes Philosopher 0 thinking/eating/finished; order varies.
  Deadlock avoided by allowing only 4 of 5 philosophers to try acquiring forks.

5 Banker's Safety Algorithm:
  gcc pr5_bankers.c -o pr5_bankers
  ./pr5_bankers
  Input (whitespace separated):
  5 3
  0 1 0 / 2 0 0 / 3 0 2 / 2 1 1 / 0 0 2
  7 5 3 / 3 2 2 / 9 0 2 / 2 2 2 / 4 3 3
  3 3 2
  Sample: SAFE STATE; Safe sequence: P1 -> P3 -> P4 -> P0 -> P2

6 FIFO communication (TWO TERMINALS, in the same directory):
  gcc pr6_fifo_receiver.c -o pr6_fifo_receiver
  gcc pr6_fifo_sender.c -o pr6_fifo_sender
  Terminal A: ./pr6_fifo_receiver
  Terminal B: ./pr6_fifo_sender
  Type Hello world [Enter], Second line [Enter], then Ctrl+D.
  Sample: Characters: 24 / Words: 4 / Lines: 2
  result.txt is created. Named FIFOs fifo1 and fifo2 remain for reuse.
  Do not run two senders or receivers simultaneously on the same FIFO names.

7 Parent Child Pipes:
  gcc pr7_pipes.c -o pr7_pipes
  printf 'Hello from file\nSecond line\n' > sample.txt
  ./pr7_pipes
  Enter: sample.txt
  Output: File contents: / Hello from file / Second line

8 Disk Scheduling:
  gcc pr8_disk.c -o pr8_disk
  ./pr8_disk
  Input: 4; requests 10 20 60 80; head 50; disk size 100; choice 1, 2 or 3.
  SSTF: 50 -> 60 -> 80 -> 20 -> 10; movement 100
  SCAN: 50 -> 60 -> 80 -> 99 -> 20 -> 10; movement 138
  C-LOOK: 50 -> 60 -> 80 -> 10 -> 20; movement 110
  SCAN/C-LOOK initially move toward higher cylinder numbers.

All source files were compiled with gcc -std=c11 -Wall -Wextra -pthread and tested
on representative inputs. These are learning examples, not production software.
