#!/bin/bash
file="addressbook.txt"
while true; do
  echo -e '\n1.Create 2.View 3.Insert 4.Delete 5.Modify 6.Exit'
  read -r -p 'Choice: ' ch
  case "$ch" in
    1) touch "$file"; echo 'Address book created' ;;
    2) if [[ -f "$file" ]]; then cat "$file"; else echo 'Create book first'; fi ;;
    3) touch "$file"
       read -r -p 'Name: ' name
       read -r -p 'Phone: ' phone
       read -r -p 'Address: ' addr
       if [[ "$name$phone$addr" == *'|'* || -z "$name" ]]; then echo 'Invalid record'; continue; fi
       printf '%s|%s|%s\n' "$name" "$phone" "$addr" >> "$file"
       echo 'Inserted' ;;
    4|5) if [[ ! -f "$file" ]]; then echo 'Create book first'; continue; fi
       read -r -p 'Name to find: ' name
       if ! awk -F'|' -v n="$name" '$1==n{found=1} END{exit !found}' "$file"; then echo 'Not found'; continue; fi
       tmp=$(mktemp) || exit 1
       awk -F'|' -v n="$name" '$1!=n' "$file" > "$tmp"
       if [[ "$ch" == 5 ]]; then
         read -r -p 'New phone: ' phone
         read -r -p 'New address: ' addr
         if [[ "$name$phone$addr" == *'|'* ]]; then rm -f "$tmp"; echo 'Invalid record'; continue; fi
         printf '%s|%s|%s\n' "$name" "$phone" "$addr" >> "$tmp"
       fi
       cat "$tmp" > "$file"; rm -f "$tmp"
       if [[ "$ch" == 4 ]]; then echo 'Deleted'; else echo 'Modified'; fi ;;
    6) exit 0 ;;
    *) echo 'Invalid choice' ;;
  esac
done
