#include <stdio.h>
#define P 20
#define R 20
int main(void){
    int n,m,allocation[P][R],max[P][R],need[P][R],available[R],work[R],finish[P]={0},seq[P],count=0;
    printf("Processes (1-20): ");fflush(stdout);
    if(scanf("%d",&n)!=1||n<1||n>P)return 1;
    printf("Resource types (1-20): ");fflush(stdout);
    if(scanf("%d",&m)!=1||m<1||m>R)return 1;
    printf("Allocation matrix:\n");fflush(stdout);
    for(int i=0;i<n;i++)for(int j=0;j<m;j++)if(scanf("%d",&allocation[i][j])!=1||allocation[i][j]<0)return 1;
    printf("Maximum matrix:\n");fflush(stdout);
    for(int i=0;i<n;i++)for(int j=0;j<m;j++)if(scanf("%d",&max[i][j])!=1||max[i][j]<allocation[i][j]){puts("Invalid maximum");return 1;}
    printf("Available resources:\n");fflush(stdout);
    for(int j=0;j<m;j++)if(scanf("%d",&available[j])!=1||available[j]<0)return 1;
    for(int j=0;j<m;j++)work[j]=available[j];
    for(int i=0;i<n;i++)for(int j=0;j<m;j++)need[i][j]=max[i][j]-allocation[i][j];
    while(count<n){
        int found=0;
        for(int i=0;i<n;i++)if(!finish[i]){
            int possible=1;
            for(int j=0;j<m;j++)if(need[i][j]>work[j])possible=0;
            if(possible){for(int j=0;j<m;j++)work[j]+=allocation[i][j];finish[i]=1;seq[count++]=i;found=1;}
        }
        if(!found)break;
    }
    if(count==n){printf("SAFE STATE\nSafe sequence: ");for(int i=0;i<n;i++)printf("P%d%s",seq[i],i==n-1?"\n":" -> ");}
    else puts("UNSAFE STATE: no safe sequence");
    return 0;
}
