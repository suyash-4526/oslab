#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>
#include <ctype.h>
#include <string.h>
#define SIZE 1024
int main(void){
    if(mkfifo("fifo1",0666)<0&&errno!=EEXIST){perror("mkfifo1");return 1;}
    if(mkfifo("fifo2",0666)<0&&errno!=EEXIST){perror("mkfifo2");return 1;}
    int fd=open("fifo1",O_RDONLY);if(fd<0){perror("open fifo1");return 1;}
    FILE *fp=fopen("result.txt","w");if(!fp){perror("result.txt");close(fd);return 1;}
    char buf[SIZE];ssize_t n;long chars=0,words=0,lines=0;int inword=0,last='\n';
    while((n=read(fd,buf,sizeof buf))>0){
        for(ssize_t i=0;i<n;i++){
            unsigned char c=(unsigned char)buf[i];chars++;
            if(c=='\n')lines++;
            if(isspace(c))inword=0;else if(!inword){words++;inword=1;}
            last=c;
        }
    }
    if(n<0){perror("read");fclose(fp);close(fd);return 1;}
    close(fd);if(chars>0&&last!='\n')lines++;
    fprintf(fp,"Characters: %ld\nWords: %ld\nLines: %ld\n",chars,words,lines);fclose(fp);
    fp=fopen("result.txt","r");if(!fp){perror("result.txt");return 1;}
    fd=open("fifo2",O_WRONLY);if(fd<0){perror("open fifo2");fclose(fp);return 1;}
    while((n=fread(buf,1,sizeof buf,fp))>0){
        size_t off=0;
        while(off<(size_t)n){ssize_t w=write(fd,buf+off,(size_t)n-off);if(w<=0){perror("write");close(fd);fclose(fp);return 1;}off+=(size_t)w;}
    }
    fclose(fp);close(fd);return 0;
}
