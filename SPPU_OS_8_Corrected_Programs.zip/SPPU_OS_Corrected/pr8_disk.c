#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define MAX 100
void sort(int a[],int n){for(int i=0;i<n-1;i++)for(int j=0;j<n-i-1;j++)if(a[j]>a[j+1]){int t=a[j];a[j]=a[j+1];a[j+1]=t;}}
void sstf(const int a[],int n,int head){
    int used[MAX]={0};long total=0;printf("SSTF: %d",head);
    for(int i=0;i<n;i++){
        int best=-1;long dist=LONG_MAX;
        for(int j=0;j<n;j++)if(!used[j]&&labs((long)head-a[j])<dist){best=j;dist=labs((long)head-a[j]);}
        used[best]=1;total+=dist;head=a[best];printf(" -> %d",head);
    }printf("\nTotal head movement = %ld\n",total);
}
void scan(int a[],int n,int head,int size){
    sort(a,n);long total=0;int start=head;
    printf("SCAN: %d",head);
    int i=0;while(i<n&&a[i]<start)i++;
    for(int j=i;j<n;j++){total+=labs((long)head-a[j]);head=a[j];printf(" -> %d",head);}
    if(head!=size-1){total+=size-1-head;head=size-1;printf(" -> %d",head);}
    for(int j=i-1;j>=0;j--){total+=labs((long)head-a[j]);head=a[j];printf(" -> %d",head);}
    printf("\nTotal head movement = %ld\n",total);
}
void clook(int a[],int n,int head){
    sort(a,n);long total=0;int start=head;
    printf("C-LOOK: %d",head);
    int i=0;while(i<n&&a[i]<start)i++;
    for(int j=i;j<n;j++){total+=labs((long)head-a[j]);head=a[j];printf(" -> %d",head);}
    for(int j=0;j<i;j++){total+=labs((long)head-a[j]);head=a[j];printf(" -> %d",head);}
    printf("\nTotal head movement = %ld\n",total);
}
int main(void){
    int a[MAX],n,head,size,choice;
    printf("Number of requests (1-100): ");fflush(stdout);
    if(scanf("%d",&n)!=1||n<1||n>MAX)return 1;
    printf("Requests: ");fflush(stdout);
    for(int i=0;i<n;i++)if(scanf("%d",&a[i])!=1)return 1;
    printf("Initial head: ");fflush(stdout);if(scanf("%d",&head)!=1)return 1;
    printf("Disk size (number of cylinders): ");fflush(stdout);if(scanf("%d",&size)!=1||size<1||head<0||head>=size)return 1;
    for(int i=0;i<n;i++)if(a[i]<0||a[i]>=size){puts("Invalid request");return 1;}
    printf("1.SSTF 2.SCAN 3.C-LOOK\nChoice: ");fflush(stdout);
    if(scanf("%d",&choice)!=1)return 1;
    switch(choice){case 1:sstf(a,n,head);break;case 2:scan(a,n,head,size);break;case 3:clook(a,n,head);break;default:puts("Invalid choice");return 1;}
    return 0;
}
